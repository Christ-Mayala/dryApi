window.__STREET_CONFIG__ = {
  apiBaseUrl: 'http://localhost:5000/',
};
