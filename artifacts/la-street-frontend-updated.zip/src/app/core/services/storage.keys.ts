export const STORAGE_KEYS = {
  apiBase: 'street_api_base',
  sentryDsn: 'SENTRY_DSN',
  user: 'street_user',
  favorites: 'street_favorites',
  messages: 'street_messages',
} as const;
